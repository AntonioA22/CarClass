import UIKit

class cars
{
    var a: String = ""
    var b: String = ""
    var c: String = ""
    var d: String = ""

    func carsParts(a: String, b:String, c:String, d:String)-> String {
        return a + b + c + d
    }
}


var parts = cars()

var total = parts.carsParts(a: "engine \n", b:"color \n", c: "exhaust \n", d: "rims \n")
print(total)
